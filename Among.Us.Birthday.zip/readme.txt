== EN == To change your birthday in Among Us unzip the file
and execute the birthday.bat in the folder "Among Us Birthday" 
and follow the instructions.

== DE == Um das Geburtsdatum in Among Us zu ändern einfach die 
ZIP-Datei entpacken, die birthday.bat im Ordner 'Among Us Birthday' 
ausführen und den Anweisungen folgen.