Um das Geburtsdatum in Among Us zu ändern einfach die ZIP-Datei entpacken,
die birthday.bat im Ordner 'Among Us Birthday' ausführen
und den Anweisungen folgen.